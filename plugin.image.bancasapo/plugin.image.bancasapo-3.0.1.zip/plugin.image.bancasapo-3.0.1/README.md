# plugin.image.bancasapo

![Kodi Addon-Check (Krypton)](https://github.com/enen92/plugin.image.bancasapo/workflows/Kodi%20Addon-Check%20(Krypton)/badge.svg)
![Kodi Addon-Check (Matrix)](https://github.com/enen92/plugin.image.bancasapo/workflows/Kodi%20Addon-Check%20(Matrix)/badge.svg)

Daily portuguese newspapper covers in Kodi

* Screenshots

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-01.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-02.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-03.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-04.jpg?raw=true)
