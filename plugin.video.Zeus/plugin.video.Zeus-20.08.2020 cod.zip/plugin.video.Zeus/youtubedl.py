<utube></utube>
<link>ignorme</link>
<jsonrpc>plugin://plugin.video.youtube/playlist/kkkkkk</jsonrpc>
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 
<channels>
<channel>
<name>[COLOR yellow][B]CANTINHO DA CRIANÇA[/B][/COLOR]</name>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</subitem>
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

<item>
<title>[COLOR lawngreen][B]O MAR NÃO ESTÁ PARA PEIXE 1[/COLOR][COLOR white] BR[/B][/COLOR]</title>
<utube>Is81EJizscI</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</fanart>
</item>

<item>
<title>[COLOR lawngreen][B]O MAR NÃO ESTÁ PARA PEIXE 2[/COLOR][COLOR white] BR[/B][/COLOR]</title>
<utube>-Aw7zVjd_P4</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</fanart>
</item>

<item>
<title>[COLOR lawngreen][B]ANY MALU [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>VKrv6FS2fkg</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]ANY MALU [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>0nmNAyUaNpI</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


 


<item>
<title>[COLOR lawngreen][B]AVENTURAS DO MAX [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>Qo2pG_Cjhjk</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>




<item>
<title>[COLOR lawngreen][B]BERNARD BEAR [/COLOR] [COLOR white]EN[/B][/COLOR]</title>
<utube>tqKZJGgXFeU</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 

<utube></utube>

<item>
<title>[COLOR lawngreen][B]BOB - O CONSTRUTOR [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>VO8FTT1zDqw</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>




<item>
<title>[COLOR lawngreen][B]CAILLOU [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>YXwE7AX30Ik</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


<item>
<title>[COLOR lawngreen][B]CANÇÕES DOS MIÚDOS [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>RMn6AXaqseA</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>

<item>
<title>[COLOR lawngreen][B]CONTOS INFANTIS [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>5Iup7m1IjOA</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


<item>
<title>[COLOR lawngreen][B]DARTACÃO [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>vbubg1KOFBo</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>

 <item>
<title>[COLOR lawngreen][B]DARTAGNAN E OS 3 MOSQUETEIROS [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>E5gkRpl7NuU</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]DORAEMON - E o Expresso do Tempo [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>C5w8T4AWmgI</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]D0RAEMON - A Caixinha Chusingura  [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>IPTB1H4gkiY</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]ERA UMA VEZ O HOMEM - O Nascimento da Terra[/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>s5rgBF4H6b4</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


<item>
<title>[COLOR lawngreen][B]ZIG & SHARKO [/COLOR][COLOR white]EN[/B][/COLOR]</title>
<utube>5V_GV0s9wfA</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 
 
 
<item>
<title>[COLOR lawngreen][B]GARFIELD [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>jBvoQvF2vSs</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 

<item>
<title>[COLOR lawngreen][B]O CRISTAL MÁGICO [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>_0xqFlJ2zWw</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


<item>
<title>[COLOR lawngreen][B]UM PANDA EM APUROS [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>CuJrZcs-RkY</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>











<item>
<title>[COLOR lawngreen][B]MASHA E O URSO 1 [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>JhCSfP0sYTg</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]MASHA E O URSO 2 [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>eGyjr17pGsQ</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



 <item>
<title>[COLOR lawngreen][B]NODDY [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>B15xeWFXgqI</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


<item>
<title>[COLOR lawngreen][B]O MUNDO DA SARA [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>6qkCJ4n_1kc</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>








<item>
<title>[COLOR lawngreen][B]OCTONAUTAS [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>oUTNMFuH</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]PALAVRA CANTADA [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>XEqN4BsRutU</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 

 
<item>
<title>[COLOR lawngreen][B]PANDA E OS CARICAS [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>-9-WJ6Pd4O</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 
 
<item>
<title>[COLOR lawngreen][B]POCOYO  [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>jer11WlCAnQ</utube>
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



<item>
<title>[COLOR lawngreen][B]SHAUN THE SHEEP  [/COLOR][COLOR white]EN[/B][/COLOR]</title>
<utube>WwGYDA8RYZc</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>

 <item>
<title>[COLOR lawngreen][B]SHIN CHAN  [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>D1v6QwTxWA8</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 

<item>
<title>[COLOR lawngreen][B]TARTARUGAS NINJA [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>xgi_G95oGic</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 
<item>
<title>[COLOR lawngreen][B]THOMAS E OS AMIGOS [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>9XqSc2Nta7A</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>


 
<item>
<title>[COLOR lawngreen][B]TOM SAWYER [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>arvcjqkLnr8</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>



 
<item>
<title>[COLOR lawngreen][B]TURMA DA MÓNICA  [/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>ddSsRVXBtZk</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>

<item>
<title>[COLOR lawngreen][B]MÓNICA TOY[/COLOR][COLOR white]BR[/B][/COLOR]</title>
<utube>roV4MBfebA4</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>

<item>
<title>[COLOR lawngreen][B]VILA MOLEZA [/COLOR][COLOR white]PT[/B][/COLOR]</title>
<utube>dtSzEkYI4nw</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>
 
<item>
<title>[COLOR lawngreen][B]VIOLETA - MUSICAL [/COLOR][COLOR white]ES[/B][/COLOR]</title>
<utube>1t1lZ-ijSqA</utube> 
<thumbnail>https://cld.pt/dl/download/5f2380b9-67aa-4032-a4d8-5a9891e2c0f8/cantinho%20da%20crian%C3%A7a.jpg</thumbnail>
<fanart>https://cld.pt/dl/download/e49b5475-b56b-455a-b115-ab8625548ba8/CANTINHO%20DA%20CRIAN%C3%87A%202.jpg</fanart>
</item>